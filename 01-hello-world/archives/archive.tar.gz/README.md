Example 1
=========

This example shows a simple Flask application.

Running the application
-----------------------

To run this example follow these steps:

- Activate a virtual environment that contains the packages in `../requirements.txt`
- To start the application run the following command:

        (venv) $ python hello.py

- Works fine with both Windows and Linux OS.

