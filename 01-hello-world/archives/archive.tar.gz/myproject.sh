#!/bin/bash

cd /home/stepan/scripts/01-hello-world
source venv/bin/activate
python /home/stepan/scripts/01-hello-world/hello.py
